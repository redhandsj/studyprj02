package jp.tuyano.spring.boot.myapp1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HeloController {

    @RequestMapping("/")
    public String index() {
        return "this is Spring Boot sample.";
    }

}
