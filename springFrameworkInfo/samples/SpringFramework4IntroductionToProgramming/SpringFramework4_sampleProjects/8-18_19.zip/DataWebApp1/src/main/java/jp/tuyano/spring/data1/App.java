package jp.tuyano.spring.data1;

// not use!
public class App {

	public static void main(String[] args) {
		
	}

}

