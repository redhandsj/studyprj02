package jp.tuyano.spring.data1;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

public class MyPersonDataServlet extends BeanAutowiringFilterServlet {
	private static final long serialVersionUID = 1L;
	
	@Autowired
	private MyPersonDataDaoImpl dao;

	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		List<MyPersonData> list = dao.getAllEntity();
		request.setAttribute("entities", list);
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		String name = request.getParameter("name");
		List<MyPersonData> list = dao.findByName(name);
		request.setAttribute("entities", list);
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

}
