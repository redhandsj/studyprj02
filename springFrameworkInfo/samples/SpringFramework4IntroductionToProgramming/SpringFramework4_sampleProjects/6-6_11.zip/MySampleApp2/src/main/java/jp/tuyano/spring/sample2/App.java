package jp.tuyano.spring.sample2;

import java.util.Properties;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	private static ApplicationContext app;
	private static Properties mybeanProps;
	
	public static void main(String[] args) {
		app = new ClassPathXmlApplicationContext("classpath:/bean.xml");
		MyBean bean = (MyBean) app.getBean("bean1");
			
		mybeanProps = (Properties)app.getBean("mybeanprops");
		String from = mybeanProps.getProperty("keeper.from");
		String to = mybeanProps.getProperty("keeper.to");
		MyBeanKeeper keeper = new MyBeanKeeper(bean, from, to);
		System.out.println(keeper);
	}

}
