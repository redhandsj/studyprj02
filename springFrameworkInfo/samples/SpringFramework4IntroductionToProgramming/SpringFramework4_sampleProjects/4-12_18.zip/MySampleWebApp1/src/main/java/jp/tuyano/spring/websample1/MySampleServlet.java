package jp.tuyano.spring.websample1;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

public class MySampleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Autowired
	//private MyBean mybean1; // list 4-11
	private MyBean2 mybean2; // list 4-18
	
	@Override
	public void init() throws ServletException {
		super.init();
		SpringBeanAutowiringSupport
			.processInjectionBasedOnCurrentContext(this);
	}

	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		//request.setAttribute("mybean", mybean1); // list 4-11
		request.setAttribute("mybean", mybean2); // list 4-18
		request.getRequestDispatcher("/index.jsp").forward(request, response);
	}

	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) 
			throws ServletException, IOException {
		String message = request.getParameter("message");
		//mybean1.addMessage(message); // list 4-11
		mybean2.getBean().addMessage(message); // list 4-18
		response.sendRedirect("sample");
	}

}
